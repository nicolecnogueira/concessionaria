#include "veiculo.h"
#include "moto.h"
#include <string>
#include <iostream>

//CONSTRUTOR
//Recebe: dados da nova moto
Moto::Moto(string model, string chassi, string marca, int preco, int ano_de_fabricacao)
{
    setModelo(model);
    setChassi(chassi);
    setMarca(marca);
    setPreco(preco);
    setAno_de_fabricacao(ano_de_fabricacao);
    //print_Moto();
}

//FUNÇÃO DE ACESSO AO MODELO DA MOTO
//Retorna: Modelo da moto
string Moto::getModelo()
{
    return modelo;
}

//FUNÇÃO DE EDIÇÃO AO MODELO DA MOTO
//Edita o modelo da moto
void Moto::setModelo(string m)
{
    modelo = m;
}

//IMPRIME OS DADOS DA MOTO
void Moto::print_Moto() 
{
    cout << endl;
    cout << "MODELO: " << getModelo() << endl;
    cout << "MARCA: " << get_marca() << endl;
    cout << "PRECO: " << get_preco() << endl;
    cout << "CHASSI: " << get_chassi() << endl;
    cout << "ANO DE FABRICACAO: " << get_ano_de_fabricacao() << endl;
}