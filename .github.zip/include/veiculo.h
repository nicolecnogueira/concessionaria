#ifndef VEICULOS_H
#define VEICULOS_H
#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Veiculo{
    protected:
        string chassi;
        string marca;
        int preco;
        int ano_de_fabricacao;

    public:
        //CONSTRUTOR
        Veiculo();

        //ACESSO E EDIÇÃO DO CHASSI DO VEICULO
        string get_chassi();
        void setChassi(string c);

        //ACESSO E EDIÇÃO DA MARCA DO VEICULO
        string get_marca();
        void setMarca(string m);

        //ACESSO E EDIÇÃO DO PREÇO DO VEICULO
        int get_preco();
        void setPreco(int p);

        //ACESSO E EDIÇÃO DO ANO DE FABRICAÇÃO DO VEICULO
        int get_ano_de_fabricacao();
        void setAno_de_fabricacao(int a);
};

#endif