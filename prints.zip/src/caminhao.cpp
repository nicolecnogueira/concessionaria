#include "veiculo.h"
#include "caminhao.h"
#include <string>
#include <iostream>

//CONSTRUTOR
Caminhao::Caminhao(string tipo_carga, string chassi, string marca, int preco, int ano_de_fabricacao)
{
    setTipo_Carga(tipo_carga);
    setChassi(chassi);
    setMarca(marca);
    setPreco(preco);
    setAno_de_fabricacao(ano_de_fabricacao);
    //print_caminhao();
}

//FUNÇÃO DE ACESSO AO TIPO DE CARGA
//Retorna: tipo de carga do caminhão
string Caminhao::getTipo_Carga()
{
    return tipo_de_carga;
}

//FUNÇÃO DE EDIÇÃO DO TIPO DE CARGA
//Edita o tipo de carga
void Caminhao::setTipo_Carga(string t)
{
    tipo_de_carga = t;
}

//IMPRIME OS DADOS DO CAMINHAO
void Caminhao::print_caminhao() 
{
    cout << endl;
    cout << "TIPO DE CARGA: " << getTipo_Carga() << endl;
    cout << "MARCA: " << get_marca() << endl;
    cout << "PRECO: " << get_preco() << endl;
    cout << "CHASSI: " << get_chassi() << endl;
    cout << "ANO DE FABRICACAO: " << get_ano_de_fabricacao() << endl;
}