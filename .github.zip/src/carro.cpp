#include "veiculo.h"
#include "carro.h"
#include <string>
#include <iostream>

//CONSTRUTOR
//Recebe: dados do novo automovel
Carro::Carro(string t_m, string chassi, string marca, int preco, int ano_de_fabricacao)
{
    setTipo_motor(t_m);
    setMarca(marca);
    setPreco(preco);
    setChassi(chassi);
    setAno_de_fabricacao(ano_de_fabricacao);
}

//FUNÇÃO DE ACESSO AO TIPO DE MOTOR
//Retorna: tipo de motor
string Carro::getTipo_motor()
{
    return tipo_de_motor;
}

//FUNÇÃO DE EDIÇÃO DO TIPO DE MOTOR
//Edita o tipo de motor
void Carro::setTipo_motor(string t)
{
    tipo_de_motor = t;
}

//IMPRIME OS DADOS DO CARRO
void Carro::print_carro() 
{
    cout << endl;
    cout << "TIPO DE MOTOR: " << getTipo_motor() << endl;
    cout << "MARCA: " << get_marca() << endl;
    cout << "PRECO: " << get_preco() << endl;
    cout << "CHASSI: " << get_chassi() << endl;
    cout << "ANO DE FABRICACAO: " << get_ano_de_fabricacao() << endl;
}