#include "veiculo.h"
#include <iostream>
#include <string>
using std::string;

//CONSTRUTOR SEM PARAMETROS
Veiculo::Veiculo()
{
    setChassi("");
    setMarca("");
    setPreco(0);
    setAno_de_fabricacao(0);
}

//Retorna a marca do veiculo
string Veiculo::get_marca(){
    return marca;
}

//Retorna o preço do veiculo
int Veiculo::get_preco(){
    return preco;
}

//Retorna o chassi do veiculo
string Veiculo::get_chassi(){
    return chassi;
}

//retorna o ano de fabricação do veiculo
int Veiculo::get_ano_de_fabricacao(){
    return ano_de_fabricacao;
}


//FUNÇÃO DE EDIÇÃO DA MARCA
//Edita a marca do veiculo
void Veiculo::setMarca(string m)
{
    marca = m;
}


//FUNÇÃO DE EDIÇÃO DO PREÇO
//Edita o Preço do veiculo
void Veiculo::setPreco(int p){
    preco = p;
}

//FUNÇÃO DE EDIÇÃO DO ANO DE FABRICAÇÃO
//Edita o ano de fabricação
void Veiculo::setAno_de_fabricacao(int a)
{
    ano_de_fabricacao = a;
}