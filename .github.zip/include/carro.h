#ifndef CARRO_H
#define CARRO_H
#include <iostream>

#include "veiculo.h"

using namespace std;

class Carro : public Veiculo
{
    protected:
        string tipo_de_motor;

    public:
        //CONSTRUTOR
        Carro(string t_m, string chassi, string marca, int preco, int ano_de_fabricacao);

        //ACESSO E EDIÇÃO AO TIPO DE MOTOR
        string getTipo_motor();
        void setTipo_motor(string t);

        //IMPRESSÃO DO CARRO
        void print_carro();
};

#endif