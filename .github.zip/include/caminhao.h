#ifndef CAMINHAO_H
#define CAMINHAO_H
#include "veiculo.h"
#include <string>
using std::string;#ifndef CAMINHAO_H
#include <iostream>

#include "veiculo.h"

using namespace std;

class Caminhao : public Veiculo
{
    protected:
        string tipo_de_carga;

    public:
        //CONSTRUTOR
        Caminhao(string tipo_carga, string chassi, string marca, int preco, int ano_de_fabricacao);

        //ACESSO E EDIÇÃO AO TIPO DE CARGA
        string getTipo_Carga();
        void setTipo_Carga(string t);

        //IMPRIME O CAMINHAO
        void print_caminhao();
};

#endif

//Classe Caminhão, derivada da classe Veículo.
class Caminhao : public Veiculo{
	private:
		string carga;
	public:
		Caminhao(string ma, int p, string c, int a, string ca); //Construtor da classe Caminhão, possui 5 parâmetros.
		string get_carga();
};

#endif